/**
 * BCS Revision Web Application - Frontend Engine
 * Stage 2: Navigation, Dynamic Catalog Tree & Dashboard Setup
 */

// Application Global State
const State = {
  catalog: null,
  activeTab: 'dashboard',
  selectedPath: null, // Relative path of selected subject/topic/dataset
  selectedType: 'all', // Node type: 'subject', 'topic', 'subtopic', 'dataset'
  selectedData: null,  // Details of current selection
  expandedNodes: new Set(),
  searchQuery: ''
};

// --- DOM Elements Cache ---
const DOM = {
  navBtns: document.querySelectorAll('.nav-btn'),
  tabViews: document.querySelectorAll('.tab-view'),
  btnRefresh: document.getElementById('btn-refresh-catalog'),
  warningBanner: document.getElementById('warning-banner'),
  warningMessage: document.getElementById('warning-message'),
  btnShowErrors: document.getElementById('btn-show-errors'),
  
  // Dashboard Stats
  statQuestions: document.getElementById('stat-total-questions'),
  statMCQs: document.getElementById('stat-total-mcqs'),
  statFlashcards: document.getElementById('stat-total-flashcards'),
  statSubjects: document.getElementById('stat-total-subjects'),
  statDatasets: document.getElementById('stat-total-datasets'),
  subjectGrid: document.getElementById('subject-grid'),
  subjectCountBadge: document.getElementById('subject-count-badge'),

  // Hierarchy Tree & Bank
  treeSearchInput: document.getElementById('tree-search-input'),
  treeContainer: document.getElementById('tree-container'),
  btnExpandAll: document.getElementById('btn-expand-all'),
  btnCollapseAll: document.getElementById('btn-collapse-all'),
  selectionDetailsContainer: document.getElementById('selection-details-container'),

  // Practice Setup
  practiceSelectionSummary: document.getElementById('practice-selection-summary'),
  btnStartMCQ: document.getElementById('btn-start-mcq'),
  btnStartFlashcard: document.getElementById('btn-start-flashcard'),

  // Errors Modal
  modalErrors: document.getElementById('modal-errors'),
  errorListContainer: document.getElementById('error-list-container'),
  btnCloseModal: document.getElementById('btn-close-modal'),
  btnModalOk: document.getElementById('btn-modal-ok')
};

// --- Initialize App ---
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  fetchCatalog();
});

// --- Event Listeners Setup ---
function setupEventListeners() {
  // Tab Switcher
  DOM.navBtns.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Refresh Button
  DOM.btnRefresh.addEventListener('click', fetchCatalog);

  // Tree Expand / Collapse
  DOM.btnExpandAll.addEventListener('click', expandAllTreeNodes);
  DOM.btnCollapseAll.addEventListener('click', collapseAllTreeNodes);

  // Search Input
  DOM.treeSearchInput.addEventListener('input', (e) => {
    State.searchQuery = e.target.value.trim().toLowerCase();
    renderHierarchyTree();
  });

  // Modal Handlers
  DOM.btnShowErrors.addEventListener('click', () => DOM.modalErrors.classList.remove('hidden'));
  DOM.btnCloseModal.addEventListener('click', () => DOM.modalErrors.classList.add('hidden'));
  DOM.btnModalOk.addEventListener('click', () => DOM.modalErrors.classList.add('hidden'));
}

// --- Fetch Catalog from Backend ---
async function fetchCatalog() {
  try {
    DOM.btnRefresh.classList.add('loading');
    const res = await fetch('/api/catalog');
    if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
    
    State.catalog = await res.json();
    renderDashboard();
    renderHierarchyTree();
    updateWarningBanner();

    // Auto-select first subject if nothing selected
    if (!State.selectedPath && State.catalog.hierarchy) {
      const subjects = Object.keys(State.catalog.hierarchy);
      if (subjects.length > 0) {
        selectCategory(subjects[0], 'subject', subjects[0], State.catalog.hierarchy[subjects[0]]);
      }
    } else {
      renderSelectionDetails();
    }
  } catch (err) {
    console.error('Failed to fetch catalog:', err);
    alert('Failed to connect to backend server or parse dataset catalog.');
  } finally {
    DOM.btnRefresh.classList.remove('loading');
  }
}

// --- Tab Navigation ---
function switchTab(tabId) {
  State.activeTab = tabId;
  
  DOM.navBtns.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });

  DOM.tabViews.forEach(view => {
    view.classList.toggle('active', view.id === `view-${tabId}`);
  });
}

// --- Render Dashboard ---
function renderDashboard() {
  if (!State.catalog) return;

  DOM.statQuestions.textContent = State.catalog.totalQuestions || 0;
  DOM.statMCQs.textContent = State.catalog.totalMCQs || 0;
  DOM.statFlashcards.textContent = State.catalog.totalFlashcards || 0;

  const subjects = Object.keys(State.catalog.hierarchy || {});
  DOM.statSubjects.textContent = subjects.length;
  DOM.statDatasets.textContent = State.catalog.totalValidDatasets || 0;
  DOM.subjectCountBadge.textContent = `${subjects.length} Subjects`;

  // Render Subject Grid
  DOM.subjectGrid.innerHTML = '';
  if (subjects.length === 0) {
    DOM.subjectGrid.innerHTML = '<div class="empty-state"><p>No dataset categories found in data/ directory.</p></div>';
    return;
  }

  subjects.forEach(subject => {
    const subjectData = State.catalog.hierarchy[subject];
    let subjectQCount = 0;
    let topicCount = Object.keys(subjectData).length;

    // Aggregate counts
    Object.values(subjectData).forEach(topicObj => {
      Object.values(topicObj).forEach(datasets => {
        datasets.forEach(ds => subjectQCount += ds.totalCount);
      });
    });

    const card = document.createElement('div');
    card.className = 'subject-card';
    card.innerHTML = `
      <div class="subject-card-header">
        <div class="subject-card-title">${escapeHtml(subject)}</div>
        <span class="badge">${topicCount} Topics</span>
      </div>
      <div class="subject-stats-row">
        <span><strong>${subjectQCount}</strong> Questions</span>
      </div>
    `;

    card.addEventListener('click', () => {
      selectCategory(subject, 'subject', subject, subjectData);
      switchTab('question-bank');
    });

    DOM.subjectGrid.appendChild(card);
  });
}

// --- Render Warning Banner & Error Modal ---
function updateWarningBanner() {
  if (!State.catalog || !State.catalog.errors || State.catalog.errors.length === 0) {
    DOM.warningBanner.classList.add('hidden');
    return;
  }

  const errCount = State.catalog.errors.length;
  DOM.warningMessage.textContent = `${errCount} dataset file(s) failed schema validation and were excluded.`;
  DOM.warningBanner.classList.remove('hidden');

  // Populate Modal Error List
  DOM.errorListContainer.innerHTML = '';
  State.catalog.errors.forEach(err => {
    const item = document.createElement('div');
    item.className = 'error-item';
    item.innerHTML = `
      <div class="error-path">${escapeHtml(err.filePath)}</div>
      <div>${escapeHtml(err.error)}</div>
    `;
    DOM.errorListContainer.appendChild(item);
  });
}

// --- Render Hierarchy Tree ---
function renderHierarchyTree() {
  if (!State.catalog || !State.catalog.hierarchy) return;

  DOM.treeContainer.innerHTML = '';
  const hierarchy = State.catalog.hierarchy;

  Object.keys(hierarchy).forEach(subject => {
    if (matchesSearch(subject, hierarchy[subject])) {
      const subjectNode = createTreeNode(subject, 'subject', subject, hierarchy[subject], 0);
      DOM.treeContainer.appendChild(subjectNode);
    }
  });
}

function matchesSearch(subject, subjectData) {
  if (!State.searchQuery) return true;
  if (subject.toLowerCase().includes(State.searchQuery)) return true;

  for (const topic of Object.keys(subjectData)) {
    if (topic.toLowerCase().includes(State.searchQuery)) return true;
    for (const subtopic of Object.keys(subjectData[topic])) {
      if (subtopic.toLowerCase().includes(State.searchQuery)) return true;
      for (const ds of subjectData[topic][subtopic]) {
        if (ds.title.toLowerCase().includes(State.searchQuery) || ds.filePath.toLowerCase().includes(State.searchQuery)) {
          return true;
        }
      }
    }
  }
  return false;
}

function createTreeNode(name, type, pathKey, nodeData, depth) {
  const container = document.createElement('div');
  container.className = `tree-node ${depth === 0 ? 'root-node' : ''}`;

  const isExpanded = State.expandedNodes.has(pathKey) || State.searchQuery.length > 0;
  const isSelected = State.selectedPath === pathKey;

  // Calculate question count for badge
  let qCount = 0;
  if (type === 'dataset') {
    qCount = nodeData.totalCount;
  } else {
    qCount = calculateNodeQuestionCount(nodeData, type);
  }

  const item = document.createElement('div');
  item.className = `tree-item ${isSelected ? 'selected' : ''}`;
  
  let icon = '📁';
  if (type === 'subject') icon = '📘';
  else if (type === 'topic') icon = '📙';
  else if (type === 'subtopic') icon = '📂';
  else if (type === 'dataset') icon = '📄';

  const hasChildren = type !== 'dataset';

  item.innerHTML = `
    <div class="tree-label">
      ${hasChildren ? `<span class="tree-toggle">${isExpanded ? '▼' : '►'}</span>` : '<span class="tree-toggle"></span>'}
      <span>${icon} ${escapeHtml(name)}</span>
    </div>
    <span class="tree-count">${qCount}</span>
  `;

  item.addEventListener('click', (e) => {
    e.stopPropagation();
    if (hasChildren) {
      if (State.expandedNodes.has(pathKey)) {
        State.expandedNodes.delete(pathKey);
      } else {
        State.expandedNodes.add(pathKey);
      }
    }
    selectCategory(pathKey, type, name, nodeData);
    renderHierarchyTree();
  });

  container.appendChild(item);

  // Render children if expanded
  if (hasChildren && isExpanded) {
    const childrenContainer = document.createElement('div');
    childrenContainer.style.marginLeft = '12px';

    if (type === 'subject') {
      Object.keys(nodeData).forEach(topic => {
        const childPath = `${pathKey}/${topic}`;
        if (matchesSearch(topic, nodeData[topic])) {
          childrenContainer.appendChild(createTreeNode(topic, 'topic', childPath, nodeData[topic], depth + 1));
        }
      });
    } else if (type === 'topic') {
      Object.keys(nodeData).forEach(subtopic => {
        const childPath = `${pathKey}/${subtopic}`;
        childrenContainer.appendChild(createTreeNode(subtopic, 'subtopic', childPath, nodeData[subtopic], depth + 1));
      });
    } else if (type === 'subtopic') {
      nodeData.forEach(dataset => {
        const childPath = dataset.filePath;
        childrenContainer.appendChild(createTreeNode(dataset.title, 'dataset', childPath, dataset, depth + 1));
      });
    }

    container.appendChild(childrenContainer);
  }

  return container;
}

function calculateNodeQuestionCount(nodeData, type) {
  let total = 0;
  if (type === 'subject') {
    Object.values(nodeData).forEach(topicObj => {
      Object.values(topicObj).forEach(datasets => {
        datasets.forEach(ds => total += ds.totalCount);
      });
    });
  } else if (type === 'topic') {
    Object.values(nodeData).forEach(datasets => {
      datasets.forEach(ds => total += ds.totalCount);
    });
  } else if (type === 'subtopic') {
    nodeData.forEach(ds => total += ds.totalCount);
  }
  return total;
}

// --- Select Category & Render Details ---
function selectCategory(pathKey, type, name, data) {
  State.selectedPath = pathKey;
  State.selectedType = type;
  State.selectedData = data;
  renderSelectionDetails();
  updatePracticeSummary();
}

function renderSelectionDetails() {
  if (!State.selectedPath || !State.catalog) {
    DOM.selectionDetailsContainer.innerHTML = `
      <div class="empty-state">
        <h3>No Category Selected</h3>
        <p>Select a category from the hierarchy tree on the left.</p>
      </div>`;
    return;
  }

  const pathKey = State.selectedPath;
  const type = State.selectedType;
  const datasets = collectDatasetsForSelection(pathKey, type, State.selectedData);

  let totalQ = 0, totalMCQ = 0, totalFlash = 0;
  datasets.forEach(d => {
    totalQ += d.totalCount;
    totalMCQ += d.mcqCount;
    totalFlash += d.flashcardCount;
  });

  DOM.selectionDetailsContainer.innerHTML = `
    <div class="selected-category-header">
      <div class="category-path-breadcrumbs">${escapeHtml(type.toUpperCase())}</div>
      <h2>${escapeHtml(pathKey)}</h2>
      <div class="subject-stats-row margin-top-lg">
        <span><strong>${totalQ}</strong> Total Questions</span>
        <span><strong>${totalMCQ}</strong> MCQs</span>
        <span><strong>${totalFlash}</strong> Flashcards</span>
        <span><strong>${datasets.length}</strong> Datasets</span>
      </div>
    </div>

    <h3>Contained Datasets</h3>
    <table class="dataset-table">
      <thead>
        <tr>
          <th>Dataset Title</th>
          <th>Relative Path</th>
          <th>Questions</th>
          <th>MCQs</th>
          <th>Flashcards</th>
        </tr>
      </thead>
      <tbody>
        ${datasets.map(d => `
          <tr>
            <td><strong>${escapeHtml(d.title)}</strong></td>
            <td><code>${escapeHtml(d.filePath)}</code></td>
            <td>${d.totalCount}</td>
            <td>${d.mcqCount}</td>
            <td>${d.flashcardCount}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function collectDatasetsForSelection(pathKey, type, nodeData) {
  const result = [];
  if (type === 'dataset') {
    result.push(nodeData);
  } else if (type === 'subtopic') {
    nodeData.forEach(d => result.push(d));
  } else if (type === 'topic') {
    Object.values(nodeData).forEach(subList => {
      subList.forEach(d => result.push(d));
    });
  } else if (type === 'subject') {
    Object.values(nodeData).forEach(topicObj => {
      Object.values(topicObj).forEach(subList => {
        subList.forEach(d => result.push(d));
      });
    });
  }
  return result;
}

// --- Practice Summary View Update ---
function updatePracticeSummary() {
  if (!State.selectedPath) return;

  const datasets = collectDatasetsForSelection(State.selectedPath, State.selectedType, State.selectedData);
  let totalQ = 0, totalMCQ = 0, totalFlash = 0;
  datasets.forEach(d => {
    totalQ += d.totalCount;
    totalMCQ += d.mcqCount;
    totalFlash += d.flashcardCount;
  });

  DOM.practiceSelectionSummary.innerHTML = `
    <div class="selected-category-header">
      <div class="category-path-breadcrumbs">TARGET CATEGORY</div>
      <h4>${escapeHtml(State.selectedPath)}</h4>
    </div>
    <div class="subject-stats-row">
      <span><strong>${totalQ}</strong> Questions Available</span>
      <span><strong>${totalMCQ}</strong> MCQs</span>
      <span><strong>${totalFlash}</strong> Flashcards</span>
    </div>
  `;

  DOM.btnStartMCQ.disabled = totalMCQ === 0;
  DOM.btnStartFlashcard.disabled = totalFlash === 0;
}

// --- Tree Controls ---
function expandAllTreeNodes() {
  if (!State.catalog || !State.catalog.hierarchy) return;

  Object.keys(State.catalog.hierarchy).forEach(subj => {
    State.expandedNodes.add(subj);
    Object.keys(State.catalog.hierarchy[subj]).forEach(top => {
      State.expandedNodes.add(`${subj}/${top}`);
      Object.keys(State.catalog.hierarchy[subj][top]).forEach(subtop => {
        State.expandedNodes.add(`${subj}/${top}/${subtop}`);
      });
    });
  });
  renderHierarchyTree();
}

function collapseAllTreeNodes() {
  State.expandedNodes.clear();
  renderHierarchyTree();
}

// --- Utilities ---
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}