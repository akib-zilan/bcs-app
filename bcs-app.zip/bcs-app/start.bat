@echo off
echo ==================================================
echo  Starting BCS Revision Web Application Backend
echo ==================================================
echo.

start http://127.0.0.1:8000
python server.py 8000

pause