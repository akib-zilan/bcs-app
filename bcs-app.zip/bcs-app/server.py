import json
import os
import sys
import urllib.parse
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# Base directories - Always base paths on this script's absolute folder
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

class DatasetValidator:
    """Validates JSON datasets according to schema requirements."""
    
    @staticmethod
    def validate_dataset(file_path, rel_path, data):
        """
        Validates dataset structure and all questions.
        Strict integrity: If any question or top-level field is invalid, 
        the entire dataset is flagged as invalid with exact error details.
        """
        if not isinstance(data, dict):
            return False, "Root JSON value must be an object", []

        if data.get("schemaVersion") != 1:
            return False, f"Unsupported or missing schemaVersion: {data.get('schemaVersion')}", []

        title = data.get("title")
        if not title or not isinstance(title, str) or not title.strip():
            return False, "Dataset must have a non-empty string 'title'", []

        questions = data.get("questions")
        if not isinstance(questions, list):
            return False, "'questions' field must be a list", []

        valid_questions = []
        seen_ids = set()

        # Deduce hierarchy from relative path
        # Format: Subject/Topic/Subtopic/Dataset.json or deeper
        parts = rel_path.parts
        subject = parts[0] if len(parts) > 1 else "General"
        topic = parts[1] if len(parts) > 2 else "General"
        subtopic = parts[2] if len(parts) > 3 else "General"

        for idx, q in enumerate(questions):
            if not isinstance(q, dict):
                return False, f"Question at index {idx} is not an object", []

            q_id = q.get("id")
            if not q_id or not isinstance(q_id, str):
                return False, f"Question at index {idx} must have a non-empty string 'id'", []

            if q_id in seen_ids:
                return False, f"Duplicate question ID '{q_id}' found at index {idx}", []
            seen_ids.add(q_id)

            q_type = q.get("type")
            if q_type not in ("mcq", "flashcard"):
                return False, f"Question '{q_id}' (index {idx}) has invalid type '{q_type}'. Must be 'mcq' or 'flashcard'", []

            question_text = q.get("question") or q.get("front")
            if not question_text or not isinstance(question_text, str) or not question_text.strip():
                return False, f"Question '{q_id}' (index {idx}) is missing required question/front text", []

            if q_type == "mcq":
                options = q.get("options")
                if not isinstance(options, list) or len(options) != 4:
                    return False, f"MCQ question '{q_id}' (index {idx}) must have exactly 4 options", []
                for o_idx, opt in enumerate(options):
                    if not isinstance(opt, str) or not opt.strip():
                        return False, f"MCQ question '{q_id}' option at index {o_idx} must be a non-empty string", []

                answer = q.get("answer")
                if not isinstance(answer, int) or isinstance(answer, bool) or answer not in (0, 1, 2, 3):
                    return False, f"MCQ question '{q_id}' answer must be an integer between 0 and 3. Got: {answer}", []

            elif q_type == "flashcard":
                front = q.get("front")
                back = q.get("back")
                if not front or not isinstance(front, str) or not front.strip():
                    return False, f"Flashcard '{q_id}' (index {idx}) must have a non-empty 'front'", []
                if not back or not isinstance(back, str) or not back.strip():
                    return False, f"Flashcard '{q_id}' (index {idx}) must have a non-empty 'back'", []

            # Valid question - augment with normalized fields and metadata
            normalized_q = {
                "id": f"{rel_path.as_posix()}::{q_id}",
                "originalId": q_id,
                "datasetPath": rel_path.as_posix(),
                "subject": subject,
                "topic": topic,
                "subtopic": subtopic,
                "type": q_type,
                "question": question_text,
                "options": q.get("options", []),
                "answer": q.get("answer"),
                "front": q.get("front", ""),
                "back": q.get("back", ""),
                "explanation": q.get("explanation", ""),
                "tags": q.get("tags", []),
                "difficulty": q.get("difficulty", "medium")
            }
            valid_questions.append(normalized_q)

        return True, None, valid_questions


class DataScanner:
    """Scans and indexes the data directory recursively."""
    
    @staticmethod
    def scan_data():
        catalog = {
            "totalDatasets": 0,
            "totalValidDatasets": 0,
            "totalInvalidDatasets": 0,
            "totalQuestions": 0,
            "totalMCQs": 0,
            "totalFlashcards": 0,
            "errors": [],
            "hierarchy": {},
            "datasets": {}
        }

        if not DATA_DIR.exists():
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            return catalog

        for root, _, files in os.walk(DATA_DIR):
            for file in sorted(files):
                if not file.endswith(".json"):
                    continue

                full_path = Path(root) / file
                rel_path = full_path.relative_to(DATA_DIR)
                rel_path_str = rel_path.as_posix()

                catalog["totalDatasets"] += 1

                try:
                    with open(full_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except Exception as e:
                    catalog["totalInvalidDatasets"] += 1
                    catalog["errors"].append({
                        "filePath": rel_path_str,
                        "error": f"JSON syntax error or read failure: {str(e)}"
                    })
                    continue

                is_valid, error_msg, valid_questions = DatasetValidator.validate_dataset(full_path, rel_path, data)

                if not is_valid:
                    catalog["totalInvalidDatasets"] += 1
                    catalog["errors"].append({
                        "filePath": rel_path_str,
                        "error": error_msg
                    })
                    continue

                # Dataset is valid
                catalog["totalValidDatasets"] += 1
                mcq_count = sum(1 for q in valid_questions if q["type"] == "mcq")
                flashcard_count = sum(1 for q in valid_questions if q["type"] == "flashcard")

                catalog["totalQuestions"] += len(valid_questions)
                catalog["totalMCQs"] += mcq_count
                catalog["totalFlashcards"] += flashcard_count

                dataset_info = {
                    "filePath": rel_path_str,
                    "title": data.get("title", rel_path.stem),
                    "totalCount": len(valid_questions),
                    "mcqCount": mcq_count,
                    "flashcardCount": flashcard_count,
                    "tags": data.get("tags", []),
                    "questions": valid_questions
                }

                catalog["datasets"][rel_path_str] = dataset_info

                # Build hierarchy tree: Subject -> Topic -> Subtopic -> Datasets
                parts = rel_path.parts
                subject = parts[0] if len(parts) > 1 else "General"
                topic = parts[1] if len(parts) > 2 else "General"
                subtopic = parts[2] if len(parts) > 3 else "General"

                tree = catalog["hierarchy"]
                if subject not in tree:
                    tree[subject] = {}
                if topic not in tree[subject]:
                    tree[subject][topic] = {}
                if subtopic not in tree[subject][topic]:
                    tree[subject][topic][subtopic] = []

                tree[subject][topic][subtopic].append({
                    "filePath": rel_path_str,
                    "title": dataset_info["title"],
                    "totalCount": len(valid_questions),
                    "mcqCount": mcq_count,
                    "flashcardCount": flashcard_count
                })

        return catalog


class BCSRequestHandler(SimpleHTTPRequestHandler):
    """Custom HTTP Handler serving API endpoints and static frontend content."""

    def translate_path(self, path):
        """Safely map static requests to root or static/ directory."""
        parsed_url = urllib.parse.urlparse(path)
        req_path = urllib.parse.unquote(parsed_url.path)
        
        normalized = os.path.normpath(req_path)
        if ".." in normalized:
            return None

        clean_path = normalized.lstrip("/\\")
        if not clean_path:
            clean_path = "index.html"

        # Check candidate locations relative to server.py location
        candidates = [
            BASE_DIR / clean_path,
            BASE_DIR / "static" / clean_path,
            BASE_DIR / "static" / "css" / clean_path,
            BASE_DIR / "static" / "js" / clean_path
        ]

        for candidate in candidates:
            if candidate.exists() and candidate.is_file():
                return str(candidate.resolve())

        return None

    def send_json_response(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, message, status=400):
        self.send_json_response({"error": message, "status": status}, status=status)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if ".." in path:
            self.send_error_json("Access denied: Invalid path sequence.", 403)
            return

        # Route: API Catalog
        if path == "/api/catalog":
            catalog = DataScanner.scan_data()
            catalog_summary = json.loads(json.dumps(catalog))
            for key in catalog_summary["datasets"]:
                catalog_summary["datasets"][key].pop("questions", None)
            self.send_json_response(catalog_summary)
            return

        # Route: API Questions
        if path == "/api/questions":
            catalog = DataScanner.scan_data()
            target_path = query.get("path", [""])[0].strip().rstrip("/")
            q_type = query.get("type", [""])[0].strip().lower()
            include_descendants_str = query.get("includeDescendants", ["true"])[0].lower()
            include_descendants = include_descendants_str in ("true", "1", "yes")

            all_matching_questions = []

            for rel_path_str, ds_info in catalog["datasets"].items():
                match = False
                if not target_path:
                    match = True
                elif rel_path_str == target_path:
                    match = True
                elif include_descendants and (rel_path_str.startswith(target_path + "/") or rel_path_str.startswith(target_path)):
                    match = True

                if match:
                    for q in ds_info["questions"]:
                        if not q_type or q["type"] == q_type:
                            all_matching_questions.append(q)

            self.send_json_response({
                "count": len(all_matching_questions),
                "path": target_path,
                "type": q_type or "all",
                "includeDescendants": include_descendants,
                "questions": all_matching_questions
            })
            return

        # Serve static web content
        file_path = self.translate_path(self.path)
        if file_path is None or not os.path.exists(file_path):
            self.send_error_json(f"File not found for path: {self.path}", 404)
            return

        # Explicitly serve file manually to avoid directory context issues
        try:
            mime = "text/html"
            if file_path.endswith(".css"): mime = "text/css"
            elif file_path.endswith(".js"): mime = "text/javascript"
            elif file_path.endswith(".json"): mime = "application/json"

            with open(file_path, "rb") as f:
                content = f.read()

            self.send_response(200)
            self.send_header("Content-Type", f"{mime}; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error_json(str(e), 500)


def run_server(port=8000):
    host = "127.0.0.1"
    server_address = (host, port)
    httpd = HTTPServer(server_address, BCSRequestHandler)
    print(f"==================================================")
    print(f" BCS Revision Web Application Backend Server")
    print(f" Local Address: http://{host}:{port}")
    print(f" Base Directory: {BASE_DIR}")
    print(f" Data Directory: {DATA_DIR}")
    print(f"==================================================")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server gracefully...")
        httpd.server_close()

if __name__ == "__main__":
    port = 8000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port)