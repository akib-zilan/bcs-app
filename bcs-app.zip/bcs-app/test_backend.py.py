import os
import shutil
import json
import unittest
from pathlib import Path
from server import DatasetValidator, DataScanner, BCSRequestHandler

TEST_DATA_DIR = Path(__file__).parent / "data_test_tmp"

class TestBCSBackend(unittest.TestCase):

    def setUp(self):
        """Create clean isolated directory structure for testing."""
        if TEST_DATA_DIR.exists():
            shutil.rmtree(TEST_DATA_DIR)
        TEST_DATA_DIR.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        """Clean up temporary test data."""
        if TEST_DATA_DIR.exists():
            shutil.rmtree(TEST_DATA_DIR)

    def create_json(self, rel_path, content):
        full_path = TEST_DATA_DIR / rel_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            json.dump(content, f)
        return full_path

    def test_valid_dataset_validation(self):
        valid_data = {
            "schemaVersion": 1,
            "title": "Geography Basics",
            "questions": [
                {
                    "id": "geo-01",
                    "type": "mcq",
                    "question": "Capital of France?",
                    "options": ["Paris", "Rome", "Berlin", "Madrid"],
                    "answer": 0
                },
                {
                    "id": "geo-02",
                    "type": "flashcard",
                    "front": "Largest Ocean?",
                    "back": "Pacific Ocean"
                }
            ]
        }
        p = Path("SubjectA/TopicB/SubtopicC/geo.json")
        is_valid, err, questions = DatasetValidator.validate_dataset(p, p, valid_data)
        self.assertTrue(is_valid)
        self.assertIsNone(err)
        self.assertEqual(len(questions), 2)
        self.assertEqual(questions[0]["subject"], "SubjectA")
        self.assertEqual(questions[0]["topic"], "TopicB")
        self.assertEqual(questions[0]["subtopic"], "SubtopicC")

    def test_invalid_json_missing_fields(self):
        data = {
            "schemaVersion": 1,
            "title": "Missing Question Text",
            "questions": [
                {
                    "id": "q1",
                    "type": "mcq",
                    "options": ["A", "B", "C", "D"],
                    "answer": 0
                }
            ]
        }
        p = Path("Sub/Top/data.json")
        is_valid, err, _ = DatasetValidator.validate_dataset(p, p, data)
        self.assertFalse(is_valid)
        self.assertIn("missing required question/front text", err)

    def test_incorrect_mcq_options_count(self):
        data = {
            "schemaVersion": 1,
            "title": "Bad Options Count",
            "questions": [
                {
                    "id": "q1",
                    "type": "mcq",
                    "question": "Sample Question",
                    "options": ["A", "B", "C"], # Only 3 options
                    "answer": 0
                }
            ]
        }
        p = Path("Sub/Top/data.json")
        is_valid, err, _ = DatasetValidator.validate_dataset(p, p, data)
        self.assertFalse(is_valid)
        self.assertIn("must have exactly 4 options", err)

    def test_invalid_answer_index(self):
        data = {
            "schemaVersion": 1,
            "title": "Bad Answer Index",
            "questions": [
                {
                    "id": "q1",
                    "type": "mcq",
                    "question": "Sample Question",
                    "options": ["A", "B", "C", "D"],
                    "answer": 4 # Out of range (0-3 allowed)
                }
            ]
        }
        p = Path("Sub/Top/data.json")
        is_valid, err, _ = DatasetValidator.validate_dataset(p, p, data)
        self.assertFalse(is_valid)
        self.assertIn("integer between 0 and 3", err)

    def test_duplicate_question_ids(self):
        data = {
            "schemaVersion": 1,
            "title": "Duplicate IDs",
            "questions": [
                {
                    "id": "q1",
                    "type": "flashcard",
                    "front": "Front 1",
                    "back": "Back 1"
                },
                {
                    "id": "q1", # Duplicate
                    "type": "flashcard",
                    "front": "Front 2",
                    "back": "Back 2"
                }
            ]
        }
        p = Path("Sub/Top/data.json")
        is_valid, err, _ = DatasetValidator.validate_dataset(p, p, data)
        self.assertFalse(is_valid)
        self.assertIn("Duplicate question ID 'q1'", err)

    def test_multiple_folder_depths_and_descendants(self):
        # Override DATA_DIR temporarily for scanner test
        import server
        original_data_dir = server.DATA_DIR
        server.DATA_DIR = TEST_DATA_DIR

        try:
            # File 1 at Depth 2
            self.create_json("Bangla/Grammar/idioms.json", {
                "schemaVersion": 1,
                "title": "Bangla Idioms",
                "questions": [
                    {"id": "b1", "type": "flashcard", "front": "Akash Kushum", "back": "Unrealistic idea"}
                ]
            })

            # File 2 at Depth 3
            self.create_json("Bangla/Literature/Modern/poets.json", {
                "schemaVersion": 1,
                "title": "Modern Poets",
                "questions": [
                    {
                        "id": "p1",
                        "type": "mcq",
                        "question": "Who wrote Bidrohi?",
                        "options": ["Kazi Nazrul Islam", "Rabindranath Tagore", "Jibanananda Das", "Jasimuddin"],
                        "answer": 0
                    }
                ]
            })

            catalog = DataScanner.scan_data()
            self.assertEqual(catalog["totalValidDatasets"], 2)
            self.assertEqual(catalog["totalQuestions"], 2)
            self.assertEqual(catalog["totalMCQs"], 1)
            self.assertEqual(catalog["totalFlashcards"], 1)

            # Test descendants logic
            all_bangla_q = []
            target = "Bangla"
            for rpath, info in catalog["datasets"].items():
                if rpath.startswith(target):
                    all_bangla_q.extend(info["questions"])
            self.assertEqual(len(all_bangla_q), 2)

        finally:
            server.DATA_DIR = original_data_dir

    def test_path_traversal_protection(self):
        handler = BCSRequestHandler.__new__(BCSRequestHandler)
        bad_path = "/../../../etc/passwd"
        translated = handler.translate_path(bad_path)
        self.assertIsNone(translated)


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestBCSBackend)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    if not result.wasSuccessful():
        exit(1)